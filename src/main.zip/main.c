#include <intrins.h>
#include"ADC.h"
#include"STC15X.h"

typedef unsigned char BYTE;
typedef unsigned int WORD;

sbit X0 = P1^2;
sbit X1 = P1^3;
sbit X2 = P1^4;
sbit X3 = P1^5;
//sbit X4 = P5^4;

sbit Y0 = P3^3;
sbit Y1 = P3^2;

sbit ADC1 = P3^1;

unsigned char actnum=0;	//动作序号

//#define ENABLE_IAP 0x80           //if SYSCLK<30MHz
//#define ENABLE_IAP 0x81           //if SYSCLK<24MHz
#define ENABLE_IAP  0x82            //if SYSCLK<20MHz
//#define ENABLE_IAP 0x83           //if SYSCLK<12MHz
//#define ENABLE_IAP 0x84           //if SYSCLK<6MHz
//#define ENABLE_IAP 0x85           //if SYSCLK<3MHz
//#define ENABLE_IAP 0x86           //if SYSCLK<2MHz
//#define ENABLE_IAP 0x87           //if SYSCLK<1MHz

// sfr IAP_DATA    =   0xC2;           //IAP数据寄存器
// sfr IAP_ADDRH   =   0xC3;           //IAP地址寄存器高字节
// sfr IAP_ADDRL   =   0xC4;           //IAP地址寄存器低字节
// sfr IAP_CMD     =   0xC5;           //IAP命令寄存器
// sfr IAP_TRIG    =   0xC6;           //IAP命令触发寄存器
// sfr IAP_CONTR   =   0xC7;           //IAP控制寄存器

#define CMD_IDLE    0               //空闲模式
#define CMD_READ    1               //IAP字节读命令
#define CMD_PROGRAM 2               //IAP字节编程命令
#define CMD_ERASE   3               //IAP扇区擦除命令


int Act1();
int Act2();
int Act3();
void Res();
void IapIdle();
BYTE IapReadByte(WORD addr);
void IapProgramByte(WORD addr, BYTE dat);
void IapEraseSector(WORD addr);


void  delay_ms(unsigned int ms)
{
     unsigned int i;
	 do{
	      i = 12000000L / 13000;
		  while(--i)	;   //14T per loop
     }while(--ms);
}

void AdcInit();
int AdcExcute();

unsigned int i;
u16 result=0;
//测试地址 第三扇区地址
WORD IAP_ADDRESS=0x0400;

void test(int count)
{
	int i;
	for ( i = 0; i < count; i++)
	{	
		Y1=0;
		delay_ms(200);
		Y1=1;
		delay_ms(200);
	}
	
}
int main()
{
	test(1);
	AdcInit();
	test(2);
	result = Get_ADC10bitResult(1);
	test(3);
	if(result==1024)
	{ 
		Y0=0;
		while(1);
	}
	result=result/10;
	delay_ms(10);
	actnum=IapReadByte(IAP_ADDRESS);
	test(4);
	Y1=0;
	delay_ms(100);
	Y1=1;

	while(1)
	{
		if(actnum>3)
			actnum=0;
		if(X3==0)
		{
			actnum=actnum+1;
			if(actnum>3)
			{
				actnum=0;
			}
			IapEraseSector(IAP_ADDRESS);
			delay_ms(10);
			IapProgramByte(IAP_ADDRESS,actnum);
			delay_ms(10);
		}
		if((X1!=0)&&(X2!=0))
		{
            if(X0==0)
            {            
				switch(actnum)
				{
					case 0:
						Act1();
						break;
					case 1:
						Act2();
						break;
					default:
						break;
				}
            }
		}
		
	}
}
		
		
		
int Act1()
{
	Y1=0;
	while(1)
	{
		if(X2==0)
		{
			delay_ms(result);
			Y0=0;
			while(1)
			{
				if(X1==0)
				{
					delay_ms(result);
					Y0=1;
					return 0;
				}
			}
		}
	}
}

int Act2()
{
	Y0=0;
	while(1)
	{
		if(X1==0)
		{
			delay_ms(result);
			Y0=1;
			while(1)
			{
				if(X1==1)
				{
					return 0;
				}
			}
		}
	}
}

void AdcInit()
{

	
	
	P1ASF = ADC_P11;
	ADC_CONTR = (ADC_CONTR & ~ADC_90T) | ADC_360T;
	ADC_CONTR |= 0x80;
	CLK_DIV |=  (1<<5);	//10位AD结果的高2位放ADC_RES的低2位，低8位在ADC_RESL。
	EADC = 1;			//中断允许		ENABLE,DISABLE
	PADC = 1;		//优先级设置	PolityHigh,PolityLow
	ADC_CONTR |=0x80;
	delay_ms(250);
	
	
}


//========================================================================
// 函数: u16	Get_ADC10bitResult(u8 channel)
// 描述: 查询法读一次ADC结果.
// 参数: channel: 选择要转换的ADC.
// 返回: 10位ADC结果.
// 版本: V1.0, 2012-10-22
//========================================================================
u16	Get_ADC10bitResult(u8 channel)	//channel = 0~7
{
	u16	adc;
	u8	i;

	if(channel > ADC_CH7)	return	1024;	//错误,返回1024,调用的程序判断	
	ADC_RES = 0;
	ADC_RESL = 0;

	ADC_CONTR = (ADC_CONTR & 0xe0) | ADC_START | channel; 
	_nop_();	
	//对ADC_CONTR操作后要4T之后才能访问
	_nop_();
	_nop_();
	_nop_();

	for(i=0; i<250; i++)		//超时
	{
		if(ADC_CONTR & ADC_FLAG)
		{
			ADC_CONTR &= ~ADC_FLAG;
			if(CLK_DIV &  (1<<5))		//10位AD结果的高2位放ADC_RES的低2位，低8位在ADC_RESL。
			{
				adc = (u16)(ADC_RES & 3);
				adc = (adc << 8) | ADC_RESL;
			}
			else		//10位AD结果的高8位放ADC_RES，低2位在ADC_RESL的低2位。
			{
				adc = (u16)ADC_RES;
				adc = (adc << 2) | (ADC_RESL & 3);
			}
			return	adc;
		}
	}
	return	1024;	//错误,返回1024,调用的程序判断
}

/*----------------------------
关闭IAP
----------------------------*/
void IapIdle()
{
    IAP_CONTR = 0;                  //关闭IAP功能
    IAP_CMD = 0;                    //清除命令寄存器
    IAP_TRIG = 0;                   //清除触发寄存器
    IAP_ADDRH = 0x80;               //将地址设置到非IAP区域
    IAP_ADDRL = 0;
}

/*----------------------------
从ISP/IAP/EEPROM区域读取一字节
----------------------------*/
BYTE IapReadByte(WORD addr)
{
    BYTE dat;                       //数据缓冲区

    IAP_CONTR = ENABLE_IAP;         //使能IAP
    IAP_CMD = CMD_READ;             //设置IAP命令
    IAP_ADDRL = addr;               //设置IAP低地址
    IAP_ADDRH = addr >> 8;          //设置IAP高地址
    IAP_TRIG = 0x5a;                //写触发命令(0x5a)
    IAP_TRIG = 0xa5;                //写触发命令(0xa5)
    _nop_();                        //等待ISP/IAP/EEPROM操作完成
    dat = IAP_DATA;                 //读ISP/IAP/EEPROM数据
    IapIdle();                      //关闭IAP功能

    return dat;                     //返回
}

/*----------------------------
写一字节数据到ISP/IAP/EEPROM区域
----------------------------*/
void IapProgramByte(WORD addr, BYTE dat)
{
    IAP_CONTR = ENABLE_IAP;         //使能IAP
    IAP_CMD = CMD_PROGRAM;          //设置IAP命令
    IAP_ADDRL = addr;               //设置IAP低地址
    IAP_ADDRH = addr >> 8;          //设置IAP高地址
    IAP_DATA = dat;                 //写ISP/IAP/EEPROM数据
    IAP_TRIG = 0x5a;                //写触发命令(0x5a)
    IAP_TRIG = 0xa5;                //写触发命令(0xa5)
    _nop_();                        //等待ISP/IAP/EEPROM操作完成
    IapIdle();
}

/*----------------------------
扇区擦除
----------------------------*/
void IapEraseSector(WORD addr)
{
    IAP_CONTR = ENABLE_IAP;         //使能IAP
    IAP_CMD = CMD_ERASE;            //设置IAP命令
    IAP_ADDRL = addr;               //设置IAP低地址
    IAP_ADDRH = addr >> 8;          //设置IAP高地址
    IAP_TRIG = 0x5a;                //写触发命令(0x5a)
    IAP_TRIG = 0xa5;                //写触发命令(0xa5)
    _nop_();                        //等待ISP/IAP/EEPROM操作完成
    IapIdle();
}
